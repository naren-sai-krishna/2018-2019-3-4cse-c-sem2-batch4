<!DOCTYPE html>
<html>
  <head>
    <title>Thank You!</title>
  </head>
  <body>
    <h1>THANK YOU!</h1>
    <p>
      We have received your order, and will get back to you as soon as possible.
    </p>
  </body>
</html>