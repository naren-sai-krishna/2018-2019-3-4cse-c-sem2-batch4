INSERT INTO `products` (`product_id`, `product_name`, `product_image`, `product_description`, `product_price`) VALUES
(1, 'Car', 'car.jpg', 'It\'s a car. Batteries not included, not required. Powered by hand.', '6.00'),
(2, 'Dangerous Bear', 'dangerous-bear.jpg', 'Beware. This bear is extremely dangerous.', '8.00'),
(3, 'Fish', 'fish.jpg', 'There is something fishy going on here...', '7.50'),
(4, 'Chill Gorilla', 'gorilla.jpg', 'Unlike the dangerous bear, this one is chill.', '8.80'),
(5, 'Rubber Duck', 'rubber-duck.jpg', 'Best partner in the bath tub.', '9.75'),
(6, 'Rubiks Cube', 'rubiks-cube.jpg', 'Some say that this cube trains your intelligence. Some others claim that it\'s just frustration.', '9.30');